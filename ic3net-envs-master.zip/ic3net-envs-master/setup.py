from setuptools import setup

setup(name='ic3net_envs',
      version='0.0.1',
      install_requires=['gym','numpy']  # And any other dependencies foo needs
)
